class AuthService {
  void authenticate(String email, String password) {
    print('Authenticating $email with $password');
    // Ici, intégrez votre logique d'authentification avec une API ou une base de données.
  }
}
