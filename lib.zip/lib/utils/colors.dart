import 'package:flutter/material.dart';

const opportunitieGreen = Color(0xff2b9f95);
const primaryWhite = Color(0xffFFFFFF);


//button
const buttonBlue= Color(0xff3142B3);
//gradient colors
const gradientColorA = Color(0xff79B3EE);
const gradientColorB = Color(0xffC5DEF6);


const gradient = LinearGradient(
colors: [gradientColorA, gradientColorB],
begin: Alignment.topLeft,
end: Alignment.bottomRight,
);