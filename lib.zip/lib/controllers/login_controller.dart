import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:oopportinitie/controllers/apiConstants.dart';
import 'package:oopportinitie/model/LoginModel.dart';

import '../services/auth_service.dart';

class LoginController {
  Future<bool> loginUser({required LoginModel loginModel,}) async {

    var url = Uri.parse(opportunitieUrl+signUpEndPoint);
    var body = json.encode({
      'email': loginModel.email,
      'password': loginModel.password,
    });

    debugPrint("url: $url");
    debugPrint("response: $body");

    var response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: body
    );
    debugPrint("response: ${response.body}");

    return response.statusCode == 200;
  }
}

