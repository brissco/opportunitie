import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:oopportinitie/utils/screens.dart';

class RegisterController {
  Future<bool> registerUser({required RegisterModel registerModel,}) async {

    var url = Uri.parse(opportunitieUrl+signUpEndPoint);
    var body = json.encode({
      'email': registerModel.email,
      'password': registerModel.password,
      'name': registerModel.name,
      'location': registerModel.location,
      'status': registerModel.status,
    });

    debugPrint("url: $url");
    debugPrint("response: $body");

    var response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: body
    );
    debugPrint("response: ${response.body}");

    return response.statusCode == 200;
  }
}
