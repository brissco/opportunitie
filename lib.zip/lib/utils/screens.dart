//dependances
export 'package:flutter/material.dart';
export 'package:flutter/services.dart';

// pages
export '../views/registre/RegisterPage.dart';
export '../views/login/LoginScreen.dart';
export '../views/home/homePage.dart';
export '../views/drawer/drawerPage.dart';

//contoller
export '../controllers/login_controller.dart';
export '../controllers/apiConstants.dart';

//brice customs
export '../widgets/custom_text_field.dart';
export 'colors.dart';


//models
export '../model/registerModel.dart';



