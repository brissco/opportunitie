import 'package:flutter/material.dart';
import 'package:oopportinitie/controllers/login_controller.dart';
import 'package:oopportinitie/model/LoginModel.dart';
import 'package:oopportinitie/utils/screens.dart';
import 'package:oopportinitie/views/CustomTextField/CustomTextField.dart';
import 'package:oopportinitie/utils/colors.dart';
class LoginPage extends StatefulWidget {
  LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final _loginFormKey = GlobalKey<FormState>(); // Clé pour le formulaire
  bool isLoading = false;
  bool passwordObscured = false;

  // Utilisez une seule instance du LoginController
  final LoginController loginController = LoginController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
        child: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
    child: Form( // Utilisation du widget Form
    key: _loginFormKey, // Association de la clé du formulaire
    child: Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
    SizedBox(height: 100,),
    CustomTextFormField(
    hintText: 'Email',
    icon: Icons.email,
    controller: emailController,
    validator: (value) {
    if (value == null || value.isEmpty || value.length <= 4) {
    return "Trop court";
    }
    return null;
    },
    ),
    SizedBox(height: 20),
    CustomTextFormField(
    hintText: 'Mot de passe',
    isObscure: !passwordObscured,
    icon: Icons.lock,
    controller: passwordController,
    suffixIcon: IconButton(
    icon: Icon(
    passwordObscured ? Icons.visibility : Icons.visibility_off,
    color: Theme.of(context).iconTheme.color,
    ),
    onPressed: () {
    setState(() {
    passwordObscured = !passwordObscured;
    });
    },
    ),
    validator: (value) {
    if (value == null || value.isEmpty || value.length <= 4) {
    return "Trop court";
    }
    return null;
    },
    ),
    const SizedBox(height: 20),
    isLoading
    ? const CircularProgressIndicator()
        : ElevatedButton(
    onPressed: () async {
    if (!isLoading && _loginFormKey.currentState!.validate()) {
    setState(() {
    isLoading = true;
    });
    LoginModel loginModel = LoginModel(
    email: emailController.text,
    password: passwordController.text,
    );
    bool success = await loginController.loginUser(loginModel: loginModel);

    if (success) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Connexion réussie")));
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomePage()));
    } else {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Échec de la connexion")));
    }

    setState(() {
    isLoading = false;
    });
    }
    },
    style: ElevatedButton.styleFrom(
    backgroundColor: buttonBlue,
    foregroundColor: primaryWhite,
    shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(18.0),
    ),
    padding: const EdgeInsets.symmetric(horizontal: 40.0, vertical: 15.0),
    ),
    child: const Text('Login', style: TextStyle(fontSize: 18)),
    ),
    const SizedBox(height: 20),
    TextButton(
    onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => RegisterPage())); // Assurez-vous que RegisterPage est correctement importé
                },
                child: const Text(
                  "Vous n'avez pas de compte ? Créez-en un",
                  style: TextStyle(
                    color: opportunitieGreen,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    )
    );
  }
}
