import 'dart:convert';

// Fonction pour décoder une chaîne JSON en un objet LoginModel
LoginModel loginModelFromJson(String str) => LoginModel.fromJson(json.decode(str));

// Fonction pour encoder un objet LoginModel en une chaîne JSON
String loginModelToJson(LoginModel data) => json.encode(data.toJson());

class LoginModel {
  String? email;
  String? password;

  LoginModel({
    this.email,
    this.password,
  });

  factory LoginModel.fromJson(Map<String, dynamic> json) => LoginModel(
    email: json["email"],
    password: json["password"],
  );

  Map<String, dynamic> toJson() => {
    "email": email,
    "password": password,
  };
}
