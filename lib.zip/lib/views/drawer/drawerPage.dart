import 'package:flutter/material.dart';
import 'package:oopportinitie/utils/screens.dart';
import 'package:oopportinitie/views/worker/profil/ProfilePage.dart';

class DrawerPage extends StatefulWidget {
  const DrawerPage({super.key});

  @override
  State<DrawerPage> createState() => _DrawerPageState();
}

class _DrawerPageState extends State<DrawerPage> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      color: Colors.white.withOpacity(0.7),
      width: size.width * 0.75,
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          UserAccountsDrawerHeader(
            accountName: Text("John Doe"),
            accountEmail: Text("john.doe@example.com"),
            currentAccountPicture: CircleAvatar(
              backgroundImage: NetworkImage("https://via.placeholder.com/150"),
            ),
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text('Home'),
            onTap: () {
              // Mettez ici la logique de navigation
              Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
            },
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text('Profil'),
            onTap: () {
              // Mettez ici la logique de navigation
              Navigator.push(context, MaterialPageRoute(builder: (context) => ProfilePage()));
            },
          ),
          ListTile(
            leading: Icon(Icons.work),
            title: Text('Nouveau Travail'),
            onTap: () {
              // Mettez ici la logique de navigation
            },
          ),
          ListTile(
            leading: Icon(Icons.list),
            title: Text('Liste des Travaux'),
            onTap: () {
              // Mettez ici la logique de navigation
            },
          ),
          ListTile(
            leading: Icon(Icons.history),
            title: Text('Historique'),
            onTap: () {
              // Mettez ici la logique de navigation
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text('Paramètres'),
            onTap: () {
              // Mettez ici la logique de navigation
            },
          ),
          ListTile(
            leading: Icon(Icons.help),
            title: Text('Aide & Support'),
            onTap: () {
              // Mettez ici la logique de navigation
            },
          ),
        ],
      )
    );

  }
}

