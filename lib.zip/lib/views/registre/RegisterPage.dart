import 'package:flutter/material.dart';
import 'package:oopportinitie/controllers/Registre_controllers.dart';
import 'package:oopportinitie/model/registerModel.dart';
import 'package:oopportinitie/utils/screens.dart';
import 'package:oopportinitie/views/CustomTextField/CustomTextField.dart';
import 'package:oopportinitie/views/worker/profil/ProfilePage.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final nameController = TextEditingController();
  final locationController = TextEditingController();
  String? status = 'ACTIVE'; // Exemple de valeur par défaut
  final _registerFormKey  = GlobalKey<FormState>();
  bool isLoading = false;
  bool passwordObscured = false;

  final RegisterController controller = RegisterController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(title: Text("Créer un compte",
        style: TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.bold
      ),)),
      body: SingleChildScrollView(
        padding: EdgeInsets.only(left: 20, right: 20, top: 30, bottom: 30),
        child: Form(
          key: _registerFormKey,
          child: Column(
            children: [
              Text("Veuillez entrez vos informations !!",
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold
                ),
              ),
              SizedBox(height: 100,),
              CustomTextFormField(
                hintText: 'Email',
                icon: Icons.email,
                controller: emailController,
                validator: (value){
                  if(value.toString().length <=4){
                    return "Trop cort";
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              CustomTextFormField(
                hintText: 'Mot de passe',
                isObscure: !passwordObscured,
                icon: Icons.lock,
                controller: passwordController,
                suffixIcon: IconButton(
                  icon: Icon(
                    // Based on passwordVisible state choose the icon
                    passwordObscured
                        ? Icons.visibility
                        : Icons.visibility_off,
                    color: Colors.black,
                  ),
                  onPressed: () {
                    // Update the state i.e. toogle the state of passwordVisible variable
                    setState(() {
                      passwordObscured = !passwordObscured;
                    });
                  },
                ),
                validator: (value){
                  if(value.toString().length <=4){
                    return "Trop cort";
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              CustomTextFormField(
                hintText: 'Nom',
                icon: Icons.person,
                controller: nameController,
                validator: (value){
                  if(value.toString().length <=4){
                    return "Trop cort";
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              CustomTextFormField(
                hintText: 'Ville, Pays',
                icon: Icons.location_city,
                controller: locationController,
                validator: (value){
                  if(value.toString().length <=4){
                    return "Trop cort";
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              Container(
                height: 50,
                padding: EdgeInsets.only( left: 15, right: 15),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: Colors.black,
                    style: BorderStyle.solid,
                    width: 1
                  )

                ),
                child: DropdownButtonFormField<String>(
                  value: status,
                  onChanged: (newValue) {
                    setState(() {
                      status = newValue;
                    });
                  },
                  items: ['ACTIVE', 'INACTIVE']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                ),
              ),
              SizedBox(height: 20),
              isLoading ? const CircularProgressIndicator() : ElevatedButton(
                onPressed: () async {

                  if(isLoading){

                  }else{

                    setState(() {
                      isLoading = true;
                    });
                    try{
                      if(_registerFormKey.currentState!.validate()){
                        _registerFormKey.currentState!.save();
                        RegisterModel registerModel = RegisterModel();
                        registerModel.email = emailController.text;
                        registerModel.password = passwordController.text;
                        registerModel.name = nameController.text;
                        registerModel.location = locationController.text;
                        registerModel.status = status;
                        bool success = await controller.registerUser(
                          registerModel: registerModel,

                        );
                        if (success) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text("Inscription réussie")),
                          );
                          // Naviguer vers une autre page ou montrer un succès
                          Navigator.push(context, MaterialPageRoute(builder: (context) => const HomePage()));

                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text("Échec de l'inscription")),
                          );
                        }
                      }
                    }catch(e){
                      setState(() {
                        isLoading = false;
                      });
                    }

                    setState(() {
                      isLoading = false;
                    });
                  }
                },
                child: Text("S'inscrire",
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
