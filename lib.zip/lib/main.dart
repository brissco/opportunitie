import 'package:oopportinitie/utils/screens.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
            gradient: gradient
        ),
        child:  AnnotatedRegion<SystemUiOverlayStyle>(  //permits to change the design of android button and status bar
          value:SystemUiOverlayStyle( //like transparent
            systemNavigationBarColor: Colors.white, // navigation bar color
            statusBarIconBrightness: Brightness.dark, // status bar icons' color
            systemNavigationBarIconBrightness:Brightness.dark, //navigation bar icons' color
          ),
          child: MaterialApp(
            theme: ThemeData(
            ),
            debugShowCheckedModeBanner: false,
            initialRoute: "login",
            routes: {
              "login" : (BuildContext context) => const LoginScreen(),
            },
          ),
        )
    );
  }
}


/*
*appBar: AppBar(
          title: Text('Exemple Drawer'),
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              UserAccountsDrawerHeader(
                accountName: Text("John Doe"),
                accountEmail: Text("john.doe@example.com"),
                currentAccountPicture: CircleAvatar(
                  backgroundImage: NetworkImage("https://via.placeholder.com/150"),
                ),
              ),
              ListTile(
                leading: Icon(Icons.person),
                title: Text('Profil'),
                onTap: () {
                  Navigator.pop(context); // Ferme le drawer
                  Navigator.of(context).push(MaterialPageRoute(builder: (context) => ProfilePage()));
                },
              ),
              ListTile(
                leading: Icon(Icons.work),
                title: Text('Nouveau Travail'),
                onTap: () {
                  Navigator.pop(context); // Ferme le drawer
                  Navigator.of(context).push(MaterialPageRoute(builder: (context) => LoginScreen()));
                },
              ),
              ListTile(
                leading: Icon(Icons.list),
                title: Text('Liste des Travaux'),
                onTap: () {
                  Navigator.pop(context); // Ferme le drawer
                  Navigator.of(context).push(MaterialPageRoute(builder: (context) => WorksInProgressPage()));
                },
              ),
              ListTile(
                leading: Icon(Icons.history),
                title: Text('Historique'),
                onTap: () {
                  // Navigate to a history page (not provided in the initial code)
                },
              ),
              Divider(),
              ListTile(
                leading: Icon(Icons.settings),
                title: Text('Paramètres'),
                onTap: () {
                  // Navigate to a settings page (not provided in the initial code)
                },
              ),
              ListTile(
                leading: Icon(Icons.help),
                title: Text('Aide & Support'),
                onTap: () {
                  // Navigate to a help/support page (not provided in the initial code)
                },
              ),
            ],
          ),
        ),
        body: Center(
          child: Text('Contenu Principal'),
        ),*/