class LanguageSkill {
  String name;
  double level; // De 0.0 à 1.0, où 1.0 est le niveau le plus élevé.

  LanguageSkill({required this.name, required this.level});
}
